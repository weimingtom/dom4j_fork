/**
 * Classes to represent the DTD declarations. They are used inside the {@link org.dom4j.DocumentType} interface.
 */
package org.dom4j.dtd;