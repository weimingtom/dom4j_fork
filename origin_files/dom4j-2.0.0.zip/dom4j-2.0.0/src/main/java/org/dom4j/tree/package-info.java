/**
 * Contains the default implementations of the <i>dom4j</i> Document Object Model together with some helpful base classes for those wishing to implement their own document object model.
 */
package org.dom4j.tree;