package test;

import java.io.IOException;

import kkk.TranslatorWebServiceStub;
import kkk.TranslatorWebServiceStub.ArrayOfString;
import kkk.TranslatorWebServiceStub.GetEnCnTwoWayTranslatorResponse;

public class Test {
	/**
	 * E:\webservice\axis2-1.6.1\bin\kkk>..\wsdl2java.bat -uri http://www.webxml.com.cn
	 * /WebServices/TranslatorWebService.asmx?wsdl -p kkk -s src -o stub -a
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		TranslatorWebServiceStub stub = new TranslatorWebServiceStub();
		TranslatorWebServiceStub.GetEnCnTwoWayTranslator param = new TranslatorWebServiceStub.GetEnCnTwoWayTranslator();
		param.setWord("你好");
		GetEnCnTwoWayTranslatorResponse resp = stub.getEnCnTwoWayTranslator(param);
		ArrayOfString result = resp.getGetEnCnTwoWayTranslatorResult();
		for (String str : result.getString()) {
			System.out.println("str:" + str);
		}
	}

}
