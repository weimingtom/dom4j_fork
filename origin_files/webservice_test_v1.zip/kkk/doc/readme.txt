<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://www.w3.org/2003/05/soap-envelope">
	<soapenv:Body>
		<ns1:getEnCnTwoWayTranslator xmlns:ns1="http://WebXml.com.cn/">
			<ns1:Word>......</ns1:Word>
		</ns1:getEnCnTwoWayTranslator>
	</soapenv:Body>
</soapenv:Envelope>
